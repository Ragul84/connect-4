# Connect4- USING MINIMAX ALGORITHM

This is made by RANCID , to particapte in the sharedeum mission #5